<?php
$servername = "localhost";
$username = "root"; // change this to your database username
$password = ""; // change this to your database password
$dbname = "omsoftware"; // change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
?>
