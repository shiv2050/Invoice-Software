-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2024 at 08:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `omsoftware`
--

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `client_id` int(11) NOT NULL,
  `client_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `gst_number` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`client_id`, `client_name`, `email`, `phone`, `gst_number`, `address`, `created_at`) VALUES
(5, 'Wah Taj', 'digilumes@gmail.com', '08882269510', '1123e2423lkj', 'mirzapur uttarpradesh\r\nMirzapur', '2024-08-06 04:15:44'),
(6, 'Tata Company', 'tata@gmail.com', '8882169542', 'tata234567', 'adresss', '2024-08-06 09:19:10');

-- --------------------------------------------------------

--
-- Table structure for table `company_profile`
--

CREATE TABLE `company_profile` (
  `id` int(11) NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `gst_number` varchar(50) NOT NULL,
  `company_logo` varchar(255) DEFAULT NULL,
  `terms` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `terms_accepted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `company_profile`
--

INSERT INTO `company_profile` (`id`, `company_name`, `email`, `phone`, `address`, `gst_number`, `company_logo`, `terms`, `created_at`, `terms_accepted`) VALUES
(12, 'DigiLume', 'digilume@gmail.com', '08882169510', 'mirzapur uttarpradesh\r\nMirzapur', 'DigiLume', 'uploads/ip-camera.png', '', '2024-08-06 04:00:45', 0),
(13, 'Demo', 'demo@gmail.com', '1234567890', 'mirzapur uttarpradesh\r\nMirzapur', 'demo12345', 'uploads/networking-racks.png', '', '2024-08-06 04:04:12', 0),
(14, 'Shivtech', 'shiv@gmail.com', '8882169610', 'mirzapur uttarpradesh\r\nMirzapur', 'shivTY678', 'uploads/fgbf.png', '', '2024-08-06 04:11:56', 0),
(15, 'Orbit Technology', 'contact@orbittechno.in', '91-8830322700', 'shop no 2, Gagan Ela, Near Palace Orchid, NIBM Road Undri, Pune - 411060', '45879654123', 'uploads/orbit-technologies-logo.PNG', '                                                      <ul>\n                                                            <li>Minimum 80 % advance to start work.</li>\n                                                            <li>Quote is valid for 7 days; if material costs increase, the quote will increase.</li>\n                                                            <li>Wiring rates are per meter and will be added as extra amount in the quote.</li>\n                                                            <li>One year warranty on the product.</li>\n                                                            <li>If any additional material or labor is required, it will cost extra.</li>\n                                                        </ul>', '2024-08-09 04:18:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `head` varchar(255) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_mode` enum('credit_card','debit_card','paypal','bank_transfer','cash','check','other') NOT NULL,
  `payment_id` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `name`, `head`, `amount`, `payment_mode`, `payment_id`, `message`, `created_at`) VALUES
(3, 'Raju Bhai', '1', 11000.00, 'paypal', '35416546152sadcfds', '234ghwehjwtyumn t', '2024-08-10 02:30:48'),
(4, 'Shivendra Singh', '3', 1000.00, 'cash', '35416546152', '4124732563.8', '2024-08-10 02:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `ex_head`
--

CREATE TABLE `ex_head` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ex_head`
--

INSERT INTO `ex_head` (`id`, `name`, `created_at`) VALUES
(1, 'Masti', '2024-08-10 06:10:15'),
(3, 'Client Meeting', '2024-08-10 02:43:14'),
(4, 'Friend Food', '2024-08-10 02:44:11');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `hsn_sac_no` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount` decimal(5,2) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `product_image`, `hsn_sac_no`, `price`, `discount`, `unit`, `created_at`) VALUES
(4, 'cable', 'products/IT-Infrastructure.png', '12365', 12.00, 10.00, 'meter', '2024-08-06 09:06:41'),
(5, 'Laptop', 'products/web-development.png', '85269', 100.00, 10.00, 'piece', '2024-08-07 04:50:12'),
(6, 'Tab', 'products/digital-marketing.png', 'T5678', 5000.00, 18.00, 'piece', '2024-08-08 06:34:16');

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE `quotation` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`product_ids`)),
  `quantities` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`quantities`)),
  `adv_payment` decimal(10,2) NOT NULL,
  `taxable` enum('yes','no') NOT NULL,
  `tax_rate` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '\'0.00\'',
  `total_amount` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `company_profile_id` int(11) DEFAULT NULL,
  `prices` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quotation`
--

INSERT INTO `quotation` (`id`, `client_id`, `product_ids`, `quantities`, `adv_payment`, `taxable`, `tax_rate`, `total_amount`, `tax_amount`, `grand_total`, `created_at`, `updated_at`, `company_profile_id`, `prices`) VALUES
(88, 5, '[\"4\",\"5\"]', '[\"10\",\"12\"]', 100.00, 'yes', '18', 270.00, 48.60, 318.60, '2024-08-08', '2024-08-08 15:27:20', 12, '[\"15\",\"10.00\"]'),
(89, 5, '[\"4\",\"5\",\"6\"]', '[\"10\",\"10\",\"1\"]', 0.00, 'yes', '28', 7300.00, 2044.00, 9344.00, '2024-08-07', '2024-08-09 12:52:48', 14, '[\"10\",\"120\",\"6000\"]'),
(90, 6, '[\"4\",\"5\",\"6\"]', '[\"10\",\"1\",\"2\"]', 100.00, 'yes', '18', 11150.00, 2007.00, 13157.00, '2024-08-07', NULL, 13, '[\"15\",\"1000\",\"5000.00\"]'),
(91, 5, '[\"4\",\"5\",\"6\"]', '[\"2\",\"3\",\"1\"]', 100.00, 'yes', '18', 5390.00, 970.20, 6360.20, '2024-07-09', NULL, 12, '[\"15\",\"120\",\"5000.00\"]'),
(92, 6, '[\"4\"]', '[\"10\"]', 0.00, 'yes', '18', 120.00, 21.60, 141.60, '2024-08-09', NULL, 15, '[\"12.00\"]'),
(93, 6, '[\"4\",\"5\"]', '[\"10\",\"12\"]', 0.00, 'yes', '18', 1320.00, 237.60, 1557.60, '2024-08-09', NULL, 15, '[\"12.00\",\"100.00\"]'),
(94, 5, '[\"6\"]', '[\"100\"]', 100000.00, 'yes', '28', 500000.00, 140000.00, 640000.00, '2024-08-09', NULL, 15, '[\"5000.00\"]'),
(95, 6, '[\"5\"]', '[\"1\"]', 1.00, 'yes', '18', 100.00, 18.00, 118.00, '2024-08-09', NULL, 13, '[\"100.00\"]'),
(96, 6, '[\"5\"]', '[\"1\"]', 1.00, 'yes', '18', 100.00, 18.00, 118.00, '2024-08-09', NULL, 13, '[\"100.00\"]'),
(97, 6, '[\"5\"]', '[\"10\"]', 100.00, 'yes', '28', 1000.00, 280.00, 1280.00, '2024-08-09', NULL, 15, '[\"100.00\"]');

-- --------------------------------------------------------

--
-- Table structure for table `quotations`
--

CREATE TABLE `quotations` (
  `quotation_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `product_ids` text NOT NULL,
  `quantities` text NOT NULL,
  `taxable` enum('yes','no') NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL,
  `grand_total` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quotations`
--

INSERT INTO `quotations` (`quotation_id`, `client_id`, `product_ids`, `quantities`, `taxable`, `total_amount`, `tax_amount`, `grand_total`, `created_at`, `updated_at`) VALUES
(4, 5, '[\"2\"]', '[\"1\"]', 'no', 50000.00, 0.00, 50000.00, '2024-08-06 14:07:42', NULL),
(5, 5, '[\"2\"]', '[\"3\"]', 'yes', 150000.00, 27000.00, 177000.00, '2024-08-06 14:16:17', NULL),
(6, 5, '[\"2\"]', '[\"2\"]', 'no', 100000.00, 0.00, 100000.00, '2024-08-06 14:19:43', NULL),
(7, 5, '[\"2\",\"3\"]', '[\"1\",\"2\"]', 'yes', 90000.00, 16200.00, 106200.00, '2024-08-06 14:33:27', NULL),
(8, 5, '[\"2\",\"3\"]', '[\"10\",\"20\"]', 'no', 900000.00, 0.00, 900000.00, '2024-08-06 14:35:11', NULL),
(9, 5, '[\"4\",\"2\",\"3\"]', '[\"10\",\"1\",\"2\"]', 'yes', 90120.00, 16221.60, 106341.60, '2024-08-06 14:37:13', NULL),
(10, 5, '[\"2\",\"4\"]', '[\"1\",\"2\"]', 'yes', 50024.00, 9004.32, 59028.32, '2024-08-06 14:41:57', NULL),
(11, 5, '[\"2\"]', '[\"1\"]', 'yes', 50000.00, 9000.00, 59000.00, '2024-08-06 14:54:25', NULL),
(12, 5, '[\"2\",\"3\",\"4\"]', '[\"1\",\"2\",\"10\"]', 'yes', 90120.00, 16221.60, 106341.60, '2024-08-07 07:13:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `reg_date`) VALUES
(5, 'admin', 'digilume@gmail.com', '$2y$10$XsV7hVMHSvCqTWrj43jWj.yp4P8PSHEU2VV4BJt6vR8SVUZpGH4Oy', '2024-08-05 08:29:10'),
(6, 'mahif', 'singh@gmail.com', '$2y$10$LeH7XRu/TC991c8DgTR9EeI4D5KHkHboZyaJDRXnxVAHv1JCDaoTu', '2024-08-05 10:05:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `company_profile`
--
ALTER TABLE `company_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ex_head`
--
ALTER TABLE `ex_head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `company_profile_id` (`company_profile_id`);

--
-- Indexes for table `quotations`
--
ALTER TABLE `quotations`
  ADD PRIMARY KEY (`quotation_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `company_profile`
--
ALTER TABLE `company_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ex_head`
--
ALTER TABLE `ex_head`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quotation`
--
ALTER TABLE `quotation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `quotations`
--
ALTER TABLE `quotations`
  MODIFY `quotation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `quotation`
--
ALTER TABLE `quotation`
  ADD CONSTRAINT `quotation_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`),
  ADD CONSTRAINT `quotation_ibfk_2` FOREIGN KEY (`company_profile_id`) REFERENCES `company_profile` (`id`);

--
-- Constraints for table `quotations`
--
ALTER TABLE `quotations`
  ADD CONSTRAINT `quotations_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
